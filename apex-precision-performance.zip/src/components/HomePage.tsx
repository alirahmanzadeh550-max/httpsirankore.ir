import React from 'react';
import { ArrowLeft, Phone, ShieldCheck, Truck, Wrench } from 'lucide-react';
import { HERO_SHOWCASE_IMAGE } from '../data/products';
import { ResilientImage } from './ResilientImage';
import { OrderContactSection } from './OrderContactSection';

interface HomePageProps {
  onGoToProducts: () => void;
  onJumpToOrder: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onGoToProducts,
  onJumpToOrder,
}) => {
  return (
    <div>
      {/* Hero Section */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-8 pt-10 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Right Column: Store Intro & Actions */}
          <div className="lg:col-span-6 flex flex-col justify-between bg-zinc-50 border border-zinc-200 rounded-xl p-6 sm:p-10">
            <div>
              <div className="text-xs font-semibold text-rose-600">
                فروشگاه تخصصی قطعات اصلی کیا و هیوندای
              </div>

              <h1 className="font-display text-3xl sm:text-4xl lg:text-[42px] font-extrabold text-zinc-950 leading-[1.3] mt-3 [text-wrap:balance]">
                ایران کره؛ مرجع قطعات اصلی و اورجینال کیا و هیوندای
              </h1>

              <p className="text-base text-zinc-600 leading-relaxed mt-5">
                فروشگاه ایران کره با سال‌ها تجربه در تامین مستقیم لوازم یدکی شرکتی (Genuine Parts و Mobis)، تمامی قطعات موتوری، جلوبندی، ترمز و مصرفی خودروهای کیا و هیوندای را با تضمین اصالت کالا به دست مشتریان و تعمیرکاران محترم می‌رساند.
              </p>
            </div>

            <div className="mt-8 pt-6 border-t border-zinc-200 flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={onGoToProducts}
                className="inline-flex items-center gap-2 px-6 py-3 bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <span>مشاهده محصولات</span>
                <ArrowLeft className="w-4 h-4" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={onJumpToOrder}
                className="inline-flex items-center gap-2 px-5 py-3 bg-zinc-950 hover:bg-zinc-800 text-white text-sm font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Phone className="w-4 h-4 text-rose-400" aria-hidden="true" />
                <span>ثبت سفارش تلفنی و پیام‌رسان</span>
              </button>
            </div>
          </div>

          {/* Left Column: Beautiful Hero Visual */}
          <div className="lg:col-span-6 rounded-xl overflow-hidden border border-zinc-200 bg-zinc-100 min-h-[280px]">
            <ResilientImage
              src={HERO_SHOWCASE_IMAGE}
              alt="نمایش قطعات یدکی اصلی کیا و هیوندای در فروشگاه ایران کره"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Brief Store Highlights */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white border border-zinc-200 rounded-xl">
            <ShieldCheck className="w-6 h-6 text-rose-600" aria-hidden="true" />
            <h2 className="font-display text-lg font-bold text-zinc-950 mt-4">
              ضمانت اصالت قطعه
            </h2>
            <p className="text-sm text-zinc-600 mt-2 leading-relaxed">
              عرضه قطعات اورجینال با لیبل و بسته‌بندی اصلی هیوندای موبیس و کیا جنیون پارت بدون واسطه.
            </p>
          </div>

          <div className="p-6 bg-white border border-zinc-200 rounded-xl">
            <Wrench className="w-6 h-6 text-rose-600" aria-hidden="true" />
            <h2 className="font-display text-lg font-bold text-zinc-950 mt-4">
              مشاوره پیش از خرید
            </h2>
            <p className="text-sm text-zinc-600 mt-2 leading-relaxed">
              بررسی دقیق سازگاری قطعه با مدل و سال ساخت خودروی شما پیش از ارسال توسط کارشناسان فنی.
            </p>
          </div>

          <div className="p-6 bg-white border border-zinc-200 rounded-xl">
            <Truck className="w-6 h-6 text-rose-600" aria-hidden="true" />
            <h2 className="font-display text-lg font-bold text-zinc-950 mt-4">
              ارسال سریع به سراسر کشور
            </h2>
            <p className="text-sm text-zinc-600 mt-2 leading-relaxed">
              تحویل فوری در تهران با پیک اختصاصی و ارسال مطمئن به تمام شهرهای ایران در کمترین زمان.
            </p>
          </div>
        </div>
      </section>

      {/* Direct Ordering Section via Phone & Messengers */}
      <OrderContactSection />
    </div>
  );
};
