import React from 'react';
import { Phone } from 'lucide-react';

export type PageRoute = 'home' | 'products';

interface NavbarProps {
  activePage: PageRoute;
  onNavigate: (page: PageRoute) => void;
  onJumpToOrder: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  onNavigate,
  onJumpToOrder,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-zinc-200">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="font-display text-xl font-extrabold tracking-tight text-zinc-950 hover:text-rose-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-rose-600"
        >
          ایران کره
        </button>

        {/* Zone 2: Two Page Links */}
        <nav className="flex items-center gap-6 sm:gap-8" aria-label="منوی اصلی">
          <button
            type="button"
            onClick={() => onNavigate('home')}
            className={`relative py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-rose-600 ${
              activePage === 'home'
                ? 'text-zinc-950 font-semibold'
                : 'text-zinc-500 hover:text-zinc-950'
            }`}
          >
            صفحه اصلی
            {activePage === 'home' && (
              <span className="absolute right-0 left-0 -bottom-[19px] h-[2px] bg-rose-600" />
            )}
          </button>

          <button
            type="button"
            onClick={() => onNavigate('products')}
            className={`relative py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-rose-600 ${
              activePage === 'products'
                ? 'text-zinc-950 font-semibold'
                : 'text-zinc-500 hover:text-zinc-950'
            }`}
          >
            محصولات
            {activePage === 'products' && (
              <span className="absolute right-0 left-0 -bottom-[19px] h-[2px] bg-rose-600" />
            )}
          </button>
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onJumpToOrder}
            className="inline-flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-zinc-950"
          >
            <Phone className="w-4 h-4" aria-hidden="true" />
            <span>تماس و سفارش</span>
          </button>
        </div>
      </div>
    </header>
  );
};
