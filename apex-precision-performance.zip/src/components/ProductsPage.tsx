import React, { useMemo, useState } from 'react';
import { MessageCircle, Phone, Search, Send } from 'lucide-react';
import {
  BrandFilter,
  getTelegramOrderUrl,
  getWhatsAppOrderUrl,
  PRODUCTS,
  STORE_CONTACT,
} from '../data/products';
import { ResilientImage } from './ResilientImage';
import { OrderContactSection } from './OrderContactSection';

export const ProductsPage: React.FC = () => {
  const [brandFilter, setBrandFilter] = useState<BrandFilter>('همه');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      if (brandFilter === 'هیوندای' && product.brand === 'کیا') {
        return false;
      }
      if (brandFilter === 'کیا' && product.brand === 'هیوندای') {
        return false;
      }
      if (searchTerm.trim()) {
        const q = searchTerm.trim();
        const hay = `${product.name} ${product.compatibleModels} ${product.description}`;
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [brandFilter, searchTerm]);

  return (
    <div>
      <section className="max-w-[1200px] mx-auto px-4 sm:px-8 pt-10 pb-6">
        {/* Page Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-zinc-200">
          <div>
            <span className="text-xs font-semibold text-rose-600">
              قطعات یدکی اورجینال کیا و هیوندای
            </span>
            <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-zinc-950 mt-1">
              محصولات ایران کره
            </h1>
            <p className="text-sm text-zinc-600 mt-1.5 max-w-xl">
              برای استعلام قیمت روز و ثبت سفارش هر قطعه، مستقیماً از طریق تماس تلفنی یا پیام‌رسان‌های واتساپ، تلگرام، بله، ایتا، روبیکا و ایمو با ما در ارتباط باشید.
            </p>
          </div>

          {/* Brand Filter & Search */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="flex items-center gap-1 p-1 bg-zinc-100 rounded-lg border border-zinc-200">
              {(['همه', 'هیوندای', 'کیا'] as BrandFilter[]).map((brand) => {
                const active = brandFilter === brand;
                return (
                  <button
                    key={brand}
                    type="button"
                    onClick={() => setBrandFilter(brand)}
                    className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                      active
                        ? 'bg-zinc-950 text-white'
                        : 'text-zinc-600 hover:text-zinc-950'
                    }`}
                  >
                    {brand}
                  </button>
                );
              })}
            </div>

            <div className="relative min-w-[220px]">
              <Search
                className="w-4 h-4 text-zinc-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="جستجوی نام قطعه یا خودرو..."
                aria-label="جستجوی نام قطعه"
                className="w-full pr-9 pl-3 py-2 bg-white border border-zinc-200 rounded-lg text-xs text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="my-10 p-10 bg-zinc-50 border border-zinc-200 rounded-xl text-center">
            <p className="font-display text-base font-bold text-zinc-950">
              محصولی با این عبارت پیدا نشد
            </p>
            <p className="text-xs text-zinc-600 mt-1">
              برای استعلام قطعات خاص یا کمیاب، با شماره‌های فروشگاه تماس بگیرید.
            </p>
            <button
              type="button"
              onClick={() => {
                setBrandFilter('همه');
                setSearchTerm('');
              }}
              className="mt-4 px-4 py-2 bg-zinc-950 text-white text-xs font-semibold rounded-md cursor-pointer"
            >
              نمایش همه محصولات
            </button>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <article
                key={product.id}
                className="flex flex-col bg-white border border-zinc-200 hover:border-zinc-300 rounded-xl overflow-hidden transition-all duration-150"
              >
                {/* Product Photo */}
                <div className="aspect-[4/3] bg-zinc-50 border-b border-zinc-100 overflow-hidden">
                  <ResilientImage
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Product Body */}
                <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-zinc-500">
                      <span className="font-semibold text-rose-600">{product.brand}</span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate">{product.compatibleModels}</span>
                    </div>

                    <h2 className="font-display text-base font-bold text-zinc-950 mt-1.5 leading-snug">
                      {product.name}
                    </h2>

                    <p className="text-sm text-zinc-600 mt-2 leading-relaxed">
                      {product.description}
                    </p>
                  </div>

                  {/* Direct Ordering Actions (Phone & Messengers Only) */}
                  <div className="pt-4 border-t border-zinc-100 flex items-center gap-2">
                    <a
                      href={getWhatsAppOrderUrl(product.name)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-md transition-colors whitespace-nowrap"
                    >
                      <MessageCircle className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>سفارش در واتساپ</span>
                    </a>

                    <a
                      href={getTelegramOrderUrl(product.name)}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`سفارش ${product.name} در تلگرام`}
                      className="inline-flex items-center justify-center gap-1.5 py-2.5 px-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-900 text-xs font-semibold rounded-md transition-colors whitespace-nowrap"
                    >
                      <Send className="w-3.5 h-3.5 text-zinc-700" aria-hidden="true" />
                      <span>تلگرام</span>
                    </a>

                    <a
                      href={STORE_CONTACT.phoneHref}
                      aria-label={`تماس تلفنی برای ${product.name}`}
                      className="inline-flex items-center justify-center p-2.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-md transition-colors shrink-0"
                    >
                      <Phone className="w-3.5 h-3.5" aria-hidden="true" />
                    </a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      <OrderContactSection />
    </div>
  );
};
