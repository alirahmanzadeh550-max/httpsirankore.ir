import React, { useState } from 'react';
import { Check, Copy, MessageCircle, MessageSquare, Phone, Send, Smartphone } from 'lucide-react';
import {
  getTelegramOrderUrl,
  getWhatsAppOrderUrl,
  STORE_CONTACT,
} from '../data/products';

export const OrderContactSection: React.FC = () => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (value: string, key: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(value).catch(() => {});
    }
    setCopiedKey(key);
    window.setTimeout(() => {
      setCopiedKey((prev) => (prev === key ? null : prev));
    }, 1800);
  };

  return (
    <section
      id="order-contact-section"
      className="max-w-[1200px] mx-auto px-4 sm:px-8 py-12"
    >
      <div className="bg-zinc-950 text-white rounded-xl p-6 sm:p-10 border border-zinc-800">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Intro */}
          <div className="lg:col-span-5 space-y-3">
            <span className="text-xs font-semibold text-rose-400">
              ثبت سفارش و استعلام قیمت لحظه‌ای
            </span>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-white leading-snug">
              سفارش فقط از طریق تماس تلفنی و پیام‌رسان‌ها
            </h2>
            <p className="text-sm text-zinc-300 leading-relaxed">
              برای اطمینان از تطابق کامل قطعه با مدل خودروی کیا یا هیوندای شما، تمامی سفارش‌ها پس از مشاوره سریع با کارشناسان ایران کره از طریق تماس تلفنی یا پیام‌رسان‌های واتساپ، تلگرام، بله، ایتا، روبیکا و ایمو ثبت و ارسال می‌شوند.
            </p>
            <p className="text-xs text-zinc-400 pt-1">
              {STORE_CONTACT.hours}
            </p>
          </div>

          {/* Direct Phone & 6 Messengers */}
          <div className="lg:col-span-7 space-y-3.5">
            {/* Phone Call Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Landline */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 flex flex-col justify-between gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-zinc-400">تلفن ثابت فروشگاه</span>
                  <Phone className="w-4 h-4 text-rose-400" aria-hidden="true" />
                </div>
                <div dir="ltr" className="text-lg font-bold tracking-wide text-white text-right">
                  {STORE_CONTACT.phoneDisplay}
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={STORE_CONTACT.phoneHref}
                    className="flex-1 text-center py-2 px-3 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-md transition-colors"
                  >
                    تماس مستقیم
                  </a>
                  <button
                    type="button"
                    onClick={() => handleCopy('02133982826', 'landline')}
                    aria-label="کپی شماره ثابت"
                    className="p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-md transition-colors cursor-pointer"
                  >
                    {copiedKey === 'landline' ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Mobile */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 flex flex-col justify-between gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-zinc-400">خط مستقیم و پیام‌رسان‌ها</span>
                  <Smartphone className="w-4 h-4 text-rose-400" aria-hidden="true" />
                </div>
                <div dir="ltr" className="text-lg font-bold tracking-wide text-white text-right">
                  {STORE_CONTACT.mobileDisplay}
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={STORE_CONTACT.mobileHref}
                    className="flex-1 text-center py-2 px-3 bg-white hover:bg-zinc-100 text-zinc-950 text-xs font-semibold rounded-md transition-colors"
                  >
                    تماس همراه
                  </a>
                  <button
                    type="button"
                    onClick={() => handleCopy('09194509413', 'mobile')}
                    aria-label="کپی شماره موبایل"
                    className="p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-md transition-colors cursor-pointer"
                  >
                    {copiedKey === 'mobile' ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Messengers Grid: WhatsApp, Telegram, Bale, Eitaa, Rubika, Imo */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {/* WhatsApp */}
              <a
                href={getWhatsAppOrderUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-rose-500/60 rounded-lg p-3.5 flex items-center justify-between gap-2 transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">واتساپ</div>
                  <div dir="ltr" className="text-[11px] text-zinc-400 truncate text-right mt-0.5">
                    {STORE_CONTACT.mobileDisplay}
                  </div>
                </div>
                <MessageCircle className="w-4 h-4 text-rose-400 shrink-0" aria-hidden="true" />
              </a>

              {/* Telegram */}
              <a
                href={getTelegramOrderUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-rose-500/60 rounded-lg p-3.5 flex items-center justify-between gap-2 transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">تلگرام</div>
                  <div dir="ltr" className="text-[11px] text-zinc-400 truncate text-right mt-0.5">
                    @{STORE_CONTACT.telegramHandle}
                  </div>
                </div>
                <Send className="w-4 h-4 text-rose-400 shrink-0" aria-hidden="true" />
              </a>

              {/* Bale */}
              <a
                href={`https://ble.ir/${STORE_CONTACT.baleHandle}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-rose-500/60 rounded-lg p-3.5 flex items-center justify-between gap-2 transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">بله</div>
                  <div dir="ltr" className="text-[11px] text-zinc-400 truncate text-right mt-0.5">
                    @{STORE_CONTACT.baleHandle}
                  </div>
                </div>
                <MessageSquare className="w-4 h-4 text-rose-400 shrink-0" aria-hidden="true" />
              </a>

              {/* Eitaa */}
              <a
                href={`https://eitaa.com/${STORE_CONTACT.eitaaHandle}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-rose-500/60 rounded-lg p-3.5 flex items-center justify-between gap-2 transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">ایتا</div>
                  <div dir="ltr" className="text-[11px] text-zinc-400 truncate text-right mt-0.5">
                    @{STORE_CONTACT.eitaaHandle}
                  </div>
                </div>
                <MessageSquare className="w-4 h-4 text-rose-400 shrink-0" aria-hidden="true" />
              </a>

              {/* Rubika */}
              <a
                href={`https://rubika.ir/${STORE_CONTACT.rubikaHandle}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-rose-500/60 rounded-lg p-3.5 flex items-center justify-between gap-2 transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">روبیکا</div>
                  <div dir="ltr" className="text-[11px] text-zinc-400 truncate text-right mt-0.5">
                    @{STORE_CONTACT.rubikaHandle}
                  </div>
                </div>
                <MessageSquare className="w-4 h-4 text-rose-400 shrink-0" aria-hidden="true" />
              </a>

              {/* Imo */}
              <button
                type="button"
                onClick={() => handleCopy(STORE_CONTACT.imoNumber, 'imo')}
                className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-rose-500/60 rounded-lg p-3.5 flex items-center justify-between gap-2 transition-colors text-right cursor-pointer"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">ایمو (imo)</div>
                  <div dir="ltr" className="text-[11px] text-zinc-400 truncate text-right mt-0.5">
                    {copiedKey === 'imo' ? 'شماره کپی شد' : STORE_CONTACT.mobileDisplay}
                  </div>
                </div>
                {copiedKey === 'imo' ? (
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" aria-hidden="true" />
                ) : (
                  <Copy className="w-4 h-4 text-rose-400 shrink-0" aria-hidden="true" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
