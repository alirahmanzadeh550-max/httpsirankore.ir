import React, { useState } from 'react';
import { Navbar, PageRoute } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { ProductsPage } from './components/ProductsPage';
import { STORE_CONTACT } from './data/products';

export default function App() {
  const [activePage, setActivePage] = useState<PageRoute>('home');

  const handleNavigate = (page: PageRoute) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleJumpToOrder = () => {
    const el = document.getElementById('order-contact-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div dir="rtl" className="min-h-screen flex flex-col bg-white text-zinc-900">
      <Navbar
        activePage={activePage}
        onNavigate={handleNavigate}
        onJumpToOrder={handleJumpToOrder}
      />

      <main className="flex-1">
        {activePage === 'home' ? (
          <HomePage
            onGoToProducts={() => handleNavigate('products')}
            onJumpToOrder={handleJumpToOrder}
          />
        ) : (
          <ProductsPage />
        )}
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-zinc-200 bg-zinc-50 mt-8">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-8 py-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs text-zinc-500">
          <div className="space-y-1">
            <div className="font-display text-sm font-bold text-zinc-950">
              فروشگاه ایران کره
            </div>
            <div>{STORE_CONTACT.hours}</div>
          </div>

          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={() => handleNavigate('home')}
              className="hover:text-zinc-950 transition-colors cursor-pointer"
            >
              صفحه اصلی
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('products')}
              className="hover:text-zinc-950 transition-colors cursor-pointer"
            >
              محصولات
            </button>
            <a
              href={STORE_CONTACT.phoneHref}
              className="font-semibold text-rose-600 hover:text-rose-700 transition-colors"
            >
              {STORE_CONTACT.phoneDisplay}
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
