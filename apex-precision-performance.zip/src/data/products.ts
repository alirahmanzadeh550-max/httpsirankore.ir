export type BrandFilter = 'همه' | 'هیوندای' | 'کیا';

export interface ProductItem {
  id: string;
  name: string;
  brand: 'هیوندای' | 'کیا' | 'هیوندای و کیا';
  compatibleModels: string;
  description: string;
  image: string;
}

export const HERO_SHOWCASE_IMAGE = '/src/assets/images/hero_aria_yadak_1794593517428.jpg';

export const STORE_CONTACT = {
  storeName: 'ایران کره',
  phoneDisplay: '۰۲۱-۳۳۹۸۲۸۲۶',
  phoneHref: 'tel:+982133982826',
  mobileDisplay: '۰۹۱۹-۴۵۰۹۴۱۳',
  mobileHref: 'tel:+989194509413',
  whatsappNumber: '989194509413',
  telegramHandle: 'irankoreh_parts',
  baleHandle: 'irankoreh_parts',
  eitaaHandle: 'irankoreh_parts',
  rubikaHandle: 'irankoreh_parts',
  imoNumber: '09194509413',
  hours: 'شنبه تا چهارشنبه ۹ تا ۵ بعدازظهر · پنج‌شنبه‌ها ۹ تا ۱',
};

export const PRODUCTS: ProductItem[] = [
  {
    id: 'brake-rotor-pads',
    name: 'دیسک ترمز خنک‌شونده و لنت سرامیکی جلو',
    brand: 'هیوندای و کیا',
    compatibleModels: 'سوناتا، سانتافه، اپتیما، اسپورتیج و توسان',
    description:
      'ساخته‌شده از آلیاژ کربن‌بالا جهت دفع حرارت سریع، ترمزگیری بی‌صدا و بدون لرزش در رانندگی شهری و جاده‌ای با ضمانت اصالت جنیون پارت.',
    image: '/src/assets/images/part_brake_rotor_pads_1794593517865.jpg',
  },
  {
    id: 'oil-air-filters',
    name: 'کیت کامل فیلتر روغن و فیلتر هوای موتور',
    brand: 'هیوندای و کیا',
    compatibleModels: 'النترا، سراتو، اکسنت، ریو و آی۲۰',
    description:
      'تصفیه دقیق ذرات معلق و محافظت کامل از سیلندر و سوپاپ‌ها، افزایش راندمان احتراق و کاهش مصرف سوخت با کاغذ صافی استاندارد کره.',
    image: '/src/assets/images/part_filters_kit_1794593518193.jpg',
  },
  {
    id: 'ignition-coil-plugs',
    name: 'کوئل دوبل و شمع سوزنی ایریدیوم اصلی',
    brand: 'هیوندای',
    compatibleModels: 'سوناتا YF و LF، سانتافه DM، ازرا و جنسیس',
    description:
      'ایجاد جرقه قدرتمند و پایدار در تمام دورهای موتور، رفع لرزش درجا و بهبود شتاب اولیه خودرو با بسته‌بندی اصلی هیوندای موبیس.',
    image: '/src/assets/images/part_ignition_plugs_1794593518525.jpg',
  },
  {
    id: 'forged-control-arm',
    name: 'طبق جلو آلومینیومی به همراه بوش و سیبک',
    brand: 'کیا',
    compatibleModels: 'اپتیما JF، سورنتو، اسپورتیج QL و موهاوی',
    description:
      'بدنه فورج مقاوم در برابر ضربه‌های جاده‌ای به همراه بوش‌های لاستیکی فشرده برای حفظ تعادل فرمان و نرمی سیستم تعلیق جلو.',
    image: '/src/assets/images/part_control_arm_1794593518344.jpg',
  },
  {
    id: 'timing-chain-kit',
    name: 'کیت کامل زنجیر تایم، سفت‌کن و ریل‌ها',
    brand: 'هیوندای و کیا',
    compatibleModels: 'موتورهای ۲۴۰۰ سی‌سی تتا ۲ و ۳۵۰۰ لامبدا',
    description:
      'شامل زنجیر تایم اصلی، دنده‌تایم، سفت‌کن هیدرولیکی و کشویی‌ها برای هماهنگی دقیق سوپاپ‌ها و عملکرد بی‌صدا و مطمئن موتور.',
    image: '/src/assets/images/part_timing_kit_1794593519228.jpg',
  },
  {
    id: 'periodic-service-pack',
    name: 'پکیج تخصصی قطعات مصرفی و اورجینال',
    brand: 'هیوندای و کیا',
    compatibleModels: 'تمامی مدل‌های کیا و هیوندای ۲۰۱۲ تا ۲۰۲۴',
    description:
      'مجموعه قطعات اصلی بدنه، موتوری و جلوبندی تهیه شده مستقیم از خطوط تامین موبیس با استعلام شماره شاسی پیش از ارسال.',
    image: '/src/assets/images/hero_aria_yadak_1794593517428.jpg',
  },
];

export function getWhatsAppOrderUrl(partName?: string): string {
  const message = partName
    ? `سلام، از سایت ایران کره برای استعلام قیمت و سفارش «${partName}» پیام می‌دهم.`
    : 'سلام، برای استعلام قیمت و سفارش قطعات اصلی کیا و هیوندای از سایت ایران کره پیام می‌دهم.';
  return `https://wa.me/${STORE_CONTACT.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export function getTelegramOrderUrl(partName?: string): string {
  const message = partName
    ? `سلام، درخواست استعلام و سفارش «${partName}» را دارم.`
    : 'سلام، درخواست استعلام قیمت قطعات کیا و هیوندای را دارم.';
  return `https://t.me/${STORE_CONTACT.telegramHandle}?text=${encodeURIComponent(message)}`;
}
