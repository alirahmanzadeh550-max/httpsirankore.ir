---
name: Apex Precision Performance
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#e6bdb8'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#ac8884'
  outline-variant: '#5c403c'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690005'
  primary-container: '#dc2626'
  on-primary-container: '#fff6f5'
  inverse-primary: '#bf0715'
  secondary: '#b9c8de'
  on-secondary: '#233143'
  secondary-container: '#39485a'
  on-secondary-container: '#a7b6cc'
  tertiary: '#ffb3ad'
  on-tertiary: '#68000a'
  tertiary-container: '#d63135'
  on-tertiary-container: '#fff6f5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#d4e4fa'
  secondary-fixed-dim: '#b9c8de'
  on-secondary-fixed: '#0d1c2d'
  on-secondary-fixed-variant: '#39485a'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  headline-xl:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Sora
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-octane engineering, mechanical pedigree, and apex luxury tailored for high-end automotive spare parts procurement. It targets discerning owners, performance specialists, and certified technicians searching for certified Kia and Hyundai genuine components.

The aesthetic fuses **High-Contrast Technical Modernism** with **Sleek Automotive Tactility**:
- Visual tone mirrors modern race telemetry consoles, supercar cockpit digital clusters, and forged carbon composites.
- The interface radiates precision, aggression, and uncompromised authenticity through deep pitch-black foundations, razor-sharp structural delineation, and glowing crimson telemetry highlights.
- Micro-interactions feel crisp, instantaneous, and mechanically weighted, evoking machined switches and responsive motorsport instrument gauges.

## Colors

The palette establishes an aggressive, track-engineered dark environment built on carbon depth, metallic silver-grey structural tiers, and vibrant race red accents.

### Color Architecture
- **Primary Accent (`#dc2626` / `#ef4444` / `#b91c1c`):** Vibrant Race Red & Crimson. Used exclusively for primary calls-to-action, critical active states, real-time diagnostic alerts, and performance metrics.
- **Base Surfaces (`#09090b`, `#111115`, `#18181b`, `#222228`):** Deep charcoal and carbon obsidian tiers that reduce ocular fatigue while giving high-grade component imagery maximum pop and contrast.
- **Structural Outlines (`#27272a`, `#3f3f46`):** Hard-machined dark borders providing mechanical definition to telemetry cards and data grids.
- **Typography & Metallics (`#ffffff`, `#f4f4f5`, `#94a3b8`, `#71717a`):** Crisp white for primary reading with polished silver and brushed titanium midtones for metadata, serial numbers, and spec sheets.
- **OEM Authenticity Highlights (`#38bdf8` / `#22c55e`):** Minimal specialized status accents designated strictly for certified genuine verification badges and in-stock diagnostics.

## Typography

The typographic hierarchy combines geometric boldness with technical clarity:
- **Headlines (Sora):** Carries angular confidence and dynamic speed reminiscent of performance automotive instrument clusters and racing emblems.
- **Body (Hanken Grotesk):** Delivers clean, neutral, hyper-legible text rendering across specifications, engineering overviews, and compatibility charts.
- **Labels, Telemetry & Part Numbers (JetBrains Mono):** Provides an unapologetic industrial aesthetic for OEM part codes (e.g., `28113-F6000`), VIN decoders, technical dimensions, and real-time inventory counts.

## Layout & Spacing

The layout is built around a rigorous 12-column engineering grid engineered for dense, technical data visualization:
- **Desktop (1280px+):** 12 columns with 24px (`1.5rem`) gutters and a minimum 48px (`3rem`) lateral margins. Ideal for complex multi-attribute part filtering, exploded technical diagrams, and side-by-side spec comparisons.
- **Tablet (768px - 1279px):** 8 columns with 20px gutters and 32px margins. Reflows spec tables into collapsible inspection drawers.
- **Mobile (< 768px):** 4 columns with 16px (`1rem`) gutters and 16px (`1rem`) outer margins. Critical actions (Buy Now, VIN scanner, Part Search) stick directly into a reinforced bottom-dock cockpit command bar.

## Elevation & Depth

Visual hierarchy abandons traditional light-source drop shadows in favor of **Layered Obsidian Surfaces, Machined Stroke Borders, and Emissive Crimson Lighting**:

- **Ground Level (Canvas):** Pure deep charcoal `#09090b`. Zero elevation.
- **Level 1 (Card & Module Surfaces):** `#111115` bordered by a razor-thin 1px `#27272a` boundary.
- **Level 2 (Active Panels & Flyouts):** `#18181b` framed by `#3f3f46` with a diffused ambient undertone (`rgba(0, 0, 0, 0.7)` with 20px blur).
- **Level 3 (Command Overlays & Modals):** `#222228` suspended over a heavily blurred, 85% opacity dark backdrop (`backdrop-filter: blur(12px)`).
- **Emissive Focal Glow (Telemetry & CTAs):** Crucial interactive nodes utilize energized crimson emission rather than standard shadows: `box-shadow: 0 0 24px rgba(220, 38, 38, 0.45), 0 0 2px rgba(239, 68, 68, 0.8)`.

## Shapes

The form language is tight, geometric, and functional (`roundedness: 1`):
- Corners utilize micro-radii (4px base, 8px for major cards, 12px for system modals), reflecting the precision laser-cut edges of machined automotive components and metallic unibody chassis.
- Pill shapes are strictly forbidden to prevent an overly casual or whimsical appearance; buttons and tags remain chiselled, structural, and robust.

## Components

### Buttons
- **Primary Apex Action:** Solid `#dc2626` background, white bold Sora typography, zero or 4px corner radius, coupled with a dynamic crimson aura (`box-shadow: 0 0 20px rgba(220, 38, 38, 0.4)`). On hover, shifts to `#ef4444` with intensified radiance (`box-shadow: 0 0 28px rgba(239, 68, 68, 0.6)`).
- **Secondary Precision Action:** Solid `#18181b` core encased in a 1px `#3f3f46` metallic border with silver `#f4f4f5` text. On hover, the border flashes white/crimson with a subtle metallic shift.
- **Ghost/Tertiary:** Transparent background with `#94a3b8` typography, shifting to `#ffffff` with a subtle `#222228` background fill on hover.

### Part Spec Cards
- Fabricated on `#111115` with a 1px continuous border (`#27272a`).
- Top banner reserves a dedicated technical telemetry strip displaying the OEM Part Number in `JetBrains Mono` alongside genuine authenticity verification tags (e.g., "MOBIS / GENUINE HYUNDAI-KIA").
- Image container features high-contrast technical rendering against a subtle radial vignette background.

### Input Fields & Search Bars
- Background surface `#111115`, framed by `#27272a`.
- Floating labels and placeholders styled in `#71717a` with monospace guidance for VIN / Part queries.
- Focus state triggers an immediate 1px `#ef4444` outer border accompanied by a subtle red laser ambient glow (`box-shadow: 0 0 8px rgba(239, 68, 68, 0.3)`).

### Chips & Compatibility Badges
- High-density tags framed with 1px border.
- **Genuine OEM:** Emerald-tinted border (`#15803d`) and dark background (`#052e16`) with `#4ade80` monospace text.
- **Vehicle Match (Kia / Hyundai):** Race red border (`#b91c1c`) with `#111115` core and `#f4f4f5` text.
- **Category Filter Chips:** Neutral `#18181b` base with `#3f3f46` borders, turning primary crimson on selection.

### Lists & Technical Tables
- Dark carbon alternating zebra-striping (`#0e0e11` and `#111115`).
- Border separators use ultra-thin `#27272a`.
- Monospaced numeric alignments for fitment years, displacement, engine codes, torque specs, and stock quantities.

### Checkboxes & Toggle Switches
- Checkboxes: 16px square with 2px corner radius; dark `#18181b` base with `#3f3f46` stroke; checked state shifts to solid `#dc2626` with a crisp white geometric checkmark.
- Toggles: Industrial sliding track (`#18181b`) with a machined metallic thumb (`#f4f4f5`) that illuminates crimson when engaged.

### Specialized Component: VIN Decoder Console
- A bespoke automotive component featuring rapid sequential inputs for the 17-character VIN, paired with real-time model verification readout panels, live parts schematic mapping, and exploded assembly views.